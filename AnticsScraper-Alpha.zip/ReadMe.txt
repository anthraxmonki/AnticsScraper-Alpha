Saves to  C:\Users\Public

Can't change that for now.